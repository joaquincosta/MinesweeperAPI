# \BoardsApi

All URIs are relative to *http://example.server/minesweeper*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateBoard**](BoardsApi.md#CreateBoard) | **Post** /boards | Create a new minesweeper board
[**RetrieveBoard**](BoardsApi.md#RetrieveBoard) | **Get** /boards/{boardId} | Retrieve a board by id
[**UpdateBoard**](BoardsApi.md#UpdateBoard) | **Patch** /boards/{boardId} | Update a board


# **CreateBoard**
> IdDefinition CreateBoard(ctx, username, body)
Create a new minesweeper board

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **username** | **string**| The user name | 
  **body** | [**CreateBoardDefinition**](CreateBoardDefinition.md)| Create minesweeper board | 

### Return type

[**IdDefinition**](IdDefinition.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **RetrieveBoard**
> BoardDefinition RetrieveBoard(ctx, username, boardId)
Retrieve a board by id

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **username** | **string**| The user name | 
  **boardId** | **string**| The board indentifier | 

### Return type

[**BoardDefinition**](BoardDefinition.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **UpdateBoard**
> BoardDefinition UpdateBoard(ctx, username, boardId, body)
Update a board

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **username** | **string**| The user name | 
  **boardId** | **string**| The board indentifier | 
  **body** | [**UpdateBoardDefinition**](UpdateBoardDefinition.md)| Update board body | 

### Return type

[**BoardDefinition**](BoardDefinition.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

